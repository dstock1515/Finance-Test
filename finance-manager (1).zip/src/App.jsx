import FinanceDashboard from "./FinanceDashboard";

function App() {
  return <FinanceDashboard />;
}

export default App;
