import { useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from "recharts";

export default function FinanceDashboard() {
  const [transactions, setTransactions] = useState([]);
  const [desc, setDesc] = useState("");
  const [amount, setAmount] = useState("");

  const addTransaction = () => {
    if (!desc || isNaN(parseFloat(amount))) return;
    setTransactions([...transactions, { description: desc, amount: parseFloat(amount), date: new Date().toLocaleDateString() }]);
    setDesc("");
    setAmount("");
  };

  const total = transactions.reduce((sum, t) => sum + t.amount, 0);

  return (
    <div className="p-6 max-w-3xl mx-auto space-y-8">
      <h1 className="text-3xl font-bold">Finance Manager</h1>
      <div className="flex space-x-3">
        <input className="border p-2 flex-1" placeholder="Description" value={desc} onChange={e => setDesc(e.target.value)} />
        <input className="border p-2 w-24" type="number" placeholder="Amount" value={amount} onChange={e => setAmount(e.target.value)} />
        <button className="bg-blue-600 text-white px-4 rounded" onClick={addTransaction}>Add</button>
      </div>
      <div>
        <h2 className="text-xl font-semibold">Balance: $ {total.toFixed(2)}</h2>
        <ul className="mt-2 space-y-1">
          {transactions.map((t, i) => (
            <li key={i} className="flex justify-between border-b py-1">
              <span>{t.date} - {t.description}</span>
              <span>$ {t.amount.toFixed(2)}</span>
            </li>
          ))}
        </ul>
      </div>
      <div style={{ height: 300 }}>
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={transactions}>
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Line type="monotone" dataKey="amount" stroke="#8884d8" />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
